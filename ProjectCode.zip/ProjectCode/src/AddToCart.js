import React, { Component } from 'react'
import MyTimer from './MyTimer';

export class AddToCart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            quantitySelected: 1,
            selectedProduct: this.props.selectedProduct
        }
    }
    static getDerivedStateFromProps(newProps, prevState) {
        if (newProps.selectedProduct.productId !== prevState.selectedProduct.productId) {
            console.log("Inside getDerivedStateFromProps")
            return ({
                ...prevState, 
                quantitySelected: 1,
                selectedProduct:newProps.selectedProduct
            })
        }
        else
        {
            return ({...prevState})
        }

    }
    changeQuantityEventHandler = (opStr) => {

        if (opStr === "dec") {
            if (this.state.quantitySelected >= 1) {
                //this.setState({quantitySelected:this.state.quantitySelected-1});
                this.setState((prevState) => {
                    return ({ quantitySelected: prevState.quantitySelected - 1 })
                }, () => {
                    if (this.state.quantitySelected == 0) {
                        this.props.onCancelConfirmation();
                    }
                })
            }

        }
        else {
            if (this.props.selectedProduct.quantity > this.state.quantitySelected) {
                //this.setState({quantitySelected:this.state.quantitySelected+1});
                this.setState((prevState) => {
                    return ({ quantitySelected: prevState.quantitySelected + 1 })
                })
            }
        }
    }
    cancelEventHandler = () => {
        // Unmount the AddToCart component
        // set the value of showAddToCart(PrpductInfo state) -- false
        // trigger the event onCancelConfirmation 
        this.props.onCancelConfirmation();
    }
    buyEventHandler = () => {
        //Route to payments page
        // unmount AddTocart
        // reduce the quantity in productsArr
        var cartObj = { ...this.props.selectedProduct, quantitySelected: this.state.quantitySelected };
        //trigger the event and pass some data
        this.props.onBuyConfirmation(cartObj);
    }
    render() {
        console.log("Company Name", this.props.companyName)
        console.log("Selected Product in AddToCartComponent", this.props.selectedProduct)
        var item = { ...this.props.selectedProduct };
        return (
            <div>
                <h1>AddToCart</h1>
                <MyTimer></MyTimer>
                <div className='container'>
                    <div className='row'>
                        <div key={item.productId} className='col-4 offset-4 card bg-primary text-warning'>
                            <img src={item.imgUrl} alt={item.productName} className="card-img-top img-responsive" />
                            <div className='card-body'>
                                <h1 className='card-title text-center' >{item.productName}</h1>
                                <p className='card-text'> Quantity : {item.quantity}</p>
                                <p className='card-text'>Price : {item.price}</p>
                                <input type="button" value="-" className='btn btn-warning m-2'
                                    disabled={this.state.quantitySelected < 0}
                                    onClick={() => {
                                        this.changeQuantityEventHandler("dec");
                                    }} />
                                <span>{this.state.quantitySelected}</span>
                                <input type="button" value="+"
                                    disabled={this.state.quantitySelected >= this.props.selectedProduct.quantity}
                                    className='btn btn-warning m-2'
                                    onClick={() => {
                                        this.changeQuantityEventHandler("inc");
                                    }}
                                />
                                <br />
                                <input type="button" value="Buy" className='btn btn-success m-2' onClick={this.buyEventHandler} />
                                <input type="button" value="Cancel" className='btn btn-danger m-2' onClick={this.cancelEventHandler} />
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )
    }
}

export default AddToCart

/*
Props
-- Data which is coming from the parent
-- Can have events 
-- Immutable data
-- Local to the component

var obj={empId:101,empName:"sara"};
var obj1=obj;// reference
obj1.empId=777;
clg(obj);//{empId:777,empName:"sara"};
clg(obj1);//{empId:777,empName:"sara"};

// Shallow copy in ES6 -- spread operator
obj={empId:101,empName:"sara"};
var obj2={...obj};
obj2.empId=333;
clg(obj);//{empId:101,empName:"sara"};
clg(obj2);//{empId:333,empName:"sara"};

var obj3={...obj,salary:8888};
clg(obj3);//{empId:101,empName:"sara",salary:8888};

var obj4={...obj,empId:444};
clg(obj4);//{empId:444,empName:"sara"};

var obj5={empId:444,...obj};
clg(obj5);//{empId:101,empName:"sara"};


Buy -->
1. Unmount the AddToCart
2. Reduce the quantity available

*/