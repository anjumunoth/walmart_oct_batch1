import React, { Component } from 'react'

export class MyTimer extends Component {
    componentDidMount()
    {
        var clearIntervalId=setInterval(()=>{
            this.setState({currTime:new Date()})
        },1000)
        this.setState({clearIntervalIdId:clearIntervalId});
        //call to the server
    }
    constructor(props)
    {
        super(props);
        this.state={
            currTime:new Date(),
            clearIntervalId:0
        }
    }
    componentWillUnmount()
    {
      clearInterval(this.state.clearIntervalId);
    }
  render() {
    console.log(this.state.currTime.toLocaleString())
    return (
      <div>MyTimer
        <h1>Time : {this.state.currTime.toLocaleString()}</h1>
      </div>
    )
  }
}

export default MyTimer