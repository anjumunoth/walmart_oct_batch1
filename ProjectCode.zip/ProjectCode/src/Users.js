import React,{useState,useEffect} from 'react'
import axios from 'axios';
import {useNavigate} from "react-router-dom"

function Users(props)
{
    console.log("Hello");
    var [companyName,setCompanyName]=useState("walmart");//
    //useState return an array
    // hook -- in built hook
    // 1st time during the load -- initialise with walmart
    // component is updated -- entire function will be executed
    // maintain its state across updates
    // on updation , it will check if company Name already exists, retains its value
    //0th pos value -- companyName : data type : string ="walmart"
    // 1st pos value -- setCompanyName : data type : function
    // pointers about setState == setCompanyName
    var navigate=useNavigate();
    var [ctr,setCtr]=useState(0);
    var changeCompanyNameEventHandler=()=>{
        setCompanyName("spring people");
        // change the company Name
        // rerender the component -- execute the entire function again 
    }
    var changeCtrEventHandler=()=>{
        setCtr((prevCtr)=>{
            return (prevCtr+1);
        })
    }

    var [usersArr,setUsersArr]=useState([]);
    useEffect(()=>{
        // mimic componentDidMount
        // give the request to the server
        var serverUrl="https://jsonplaceholder.typicode.com/users";
        axios.get(serverUrl)
        .then((response)=>{
            console.log("Response of get request",response);
            setUsersArr(response.data);

        })
        .catch((err)=>{
            console.log("Error in get request",err)
        })

    },[])
    var detailsEventHandler=(selectedUser)=>{
        // navigate to the details page
        navigate("/details/"+selectedUser.id,{state:{selectedUser:selectedUser}});

    }
    var liArr=usersArr.map(item=>{
        return(
            <li key={item.id}>
                {item.id}--{item.name} --- {item.email} ---
                <input type="button" value="details" className='btn btn-primary' onClick={detailsEventHandler.bind(this,item)} />
            </li>
        )
    })
    return (
        <React.Fragment>
            <h1>Users Component</h1>
            <h2>Company Name: {companyName} </h2>
            <h2>Ctr: {ctr}</h2>
            <input type="button" value="Change company name" 
            className='btn btn-primary'
            onClick={changeCompanyNameEventHandler}
            />
            <input type="button" value="Increment ctr" 
            className='btn btn-primary'
            onClick={changeCtrEventHandler}
            />
            <br/>
            {usersArr.length> 0 
            ?<ul>
                {liArr}
            </ul>
            : <h1>Loading ....</h1>
            }
        </React.Fragment>
    )
}
export default Users;

/*
var i,j=10;
clg(i);//ud
var arr,arr2=[10,20,30];
clg(arr);//ud

var [first,second]=arr2;
clg(first);//10
clg(second);//20

var [first,,third]=arr2;
clg(third);//30



*/