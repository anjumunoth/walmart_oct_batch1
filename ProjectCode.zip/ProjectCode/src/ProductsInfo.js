import React, { Component } from 'react'
import AddToCart from './AddToCart';


export default class ProductsInfo extends Component {
    constructor()
    {
        super();
        
        this.ctr=100;
        this.state={
            showAddToCart:false,
            selectedProduct:{},
            productsArr:[
                { productId: "p101", productName: "Apple Iphone", price: 167899, quantity: 56, description: "Apple Iphone 13 pro max", imgUrl: "./images/iphone13.jpg" },
                { productId: "p102", productName: "Nokia 3310", price: 7899, quantity: 5, description: "Nokia", imgUrl: "./images/nokia.jpg" },
                { productId: "p103", productName: "One plus 9", price: 67899, quantity: 6, description: "One plus 9", imgUrl: "./images/oneplus9.jpg" },
                { productId: "p104", productName: "Google Pixel", price: 56899, quantity: 1, description: "Google pixel 256gb", imgUrl: "./images/pixel.jpg" },
                { productId: "p105", productName: "Samsung Fold 3", price: 150899, quantity: 10, description: "Samsung fold3 blue", imgUrl: "./images/samsungFold3.jpg" },
            ]

        };
        //this -- scope : component scope
        this.detailsEventHandler=this.detailsEventHandler.bind(this);
    }
    addToCartEventHandler=(selectedProduct)=>{
        console.log("Inside the add to cart event handler"+ this.ctr);//lexical scope ; component scope;//100
        //this.showAddToCart=true;
        //this.state.showAddToCart=true;//no ; will not call the render
        this.setState({showAddToCart:true, selectedProduct:selectedProduct},()=>{
            //After the foll:modified the state; completed the render method execution of ProductsInfo
            console.log("Show Add To cart"+ this.state.showAddToCart);// true
        });// update the state and call the render method again
        //console.log("Show Add To cart"+ this.state.showAddToCart);// render method again; false
        console.log("Selected product",selectedProduct);
    }
    detailsEventHandler=function(){
        console.log("Inside the details event handler"+this.ctr);//error; this is not defined
        // navigate to the details component
        // navigate to /details
        
    }
    onCancelConfirmationEventHandler=()=>{
        console.log("Inside onCancelConfirmationEventHandler");
        this.setState({showAddToCart:false});
    }
    onBuyConfirmationEventHandler=(cartObj)=>{
        
        this.setState((prevState)=>{
            var pos=prevState.productsArr.findIndex(item => item.productId === cartObj.productId);
            if(pos >=0)
            {
                prevState.productsArr[pos].quantity -= cartObj.quantitySelected;
            }
            return (
                {
                    showAddToCart:false,
                    productsArr:prevState.productsArr
                }
            )
        })
    }
    render() {
        
        var cardsArr=this.state.productsArr.map((item,index) =>{
            return(
                <div key={item.productId} className='col-4 card bg-warning text-primary'>
                <img src={item.imgUrl} alt={item.productName} className="card-img-top img-responsive"/>
                <div className='card-body'>
                    <h1 className='card-title text-center' >{item.productName}</h1>
                    <p className='card-text'> Quantity : {item.quantity}</p>
                    <p className='card-text'>Price : {item.price}</p>
                    <input type="button" value="Add To Cart" className='btn btn-primary'
                    onClick={()=>{
                        this.addToCartEventHandler(item);
                    }}
                     />
                     <input type="button" value="Details" className='btn btn-primary'
                    onClick={this.detailsEventHandler}
                     />
                </div>
            </div>

            );
        })
        return (
            <div>
                <h1>ProductsInfo</h1>
                <div className='container-fluid'>
                    <div className='row'>
                        {cardsArr}
                        
                    </div>
                </div>
                <div>
                   {this.state.showAddToCart=== true && 
                    <AddToCart 
                        selectedProduct={this.state.selectedProduct}
                        companyName="walmart"
                        onCancelConfirmation={this.onCancelConfirmationEventHandler}
                        onBuyConfirmation={this.onBuyConfirmationEventHandler}
                    >
                    </AddToCart>}
                   
                </div>
            </div>
        )
    }
}


/*
JSX
-- no loops allowed
-- no if else
-- no switch 

-- have to work with loops but not explicitly
-- Dynamic rendering -- render based on size of productsArr

Conditional rendering
-- mount the component only when a certain condition is satisfied
-- ternary operator ?:
-- logical and operator
 {this.showAddToCart=== true && <AddToCart></AddToCart>}
{this.showAddToCart ? <AddToCart></AddToCart> : null}
                
Normal html events -- no
synthetic react events -- wrapper around normal html events
In html :
<input type="button" value="Add" onclick="addEventHandler()" />
In jsx:
<input type="button" value="Add" onClick={addEventHandler} />

Best practice event handler : fat arrow function
Anonymous fucntion : Bind the scope of this


var i=0;
console.log(i);//0
i=20;

Initial page load 
React app -- return the virtual Dom
virtual DOm -- mapped to real dom
showAddToCart --false ; AddToCart will not be mounted

user clicked on button ;
eventhandler : showAddToCart -- true;
memory -- showAddToCart -- true ; 
return a new virtual DOM with the changes -- call the render method again
diffing algorithm

virtual DOM -- render -- return the virtual DOM


render method 
-- returns virtual DOM
-- called implicitly when the component is mounted (instance of component is created)
-- Called after the constructor
-- Lifecycle method
-- Cannot be called explicitly
-- Can be called multiple times
-- Call some other function(setState) which internally calls render

State of component:
-- Hold the local mutable data of component
-- Always an object
-- Always initialised in the constructor
-- Will never directly mutate the data
-- call setState() to mutate the data

setState()
-- Method with 1 mandatory param and 1 optional parameter
-- async function 
-- setState(obj/function,callback function)
-- Obj as the first param -- obj will be merged with the existing state and merged object becomes the new state
Assign new values -- obj as param
-- Function as the first param -- function has to return an object;obj will be merged with the existing state and merged object becomes the new state
Manipulate the existing values -- function as param; function will be able to access the prevState
-- Perform some task on completion of setState -- callback function
-- Callback function -- invoked implicitly after the completion of setState
-- perform 2 tasks
1. Modify the state
2. render method implicitly


update emp set salary=100 where empId=101;
// Irrespective of its old value salary=100;
update emp set salary=salary +100 where empId=102;
// Incrementing the existing value by 100

function myFunc()
{
    var i=10;
    console.log("hello");
    setInterval(()=>{
        console.log("welcome");
        i=20;
    },1000);
    console.log(i);//10
    console.log("bye");
}
//setInterval -- async operation/function
myFunc();//hello,bye , welcome

Pass data from event to event handler
<input type="button" value="Add" onClick={()=>{
    this.addEventHandler(100)
}} />

<input type="button" value="Add" onClick={this.addEventHandler.bind(this,100)} />

Data from the parent to child
Parent : ProductInfo
Child : AddToCart

<a href="" >Go To Walmart </a>
<img src="" alt="" onclick="imgEventHandler()" />
Attributes /Properties
-- as part of opening tag of element
-- provide info for the element to behave correctly
-- Can be optional or mandatory
-- Can be attributes or events and events with eventhandlers
<AddToCart companyName="walmart"><AddToCart>


state.showAddToCart -- true using setState()
1. State will be modified
2. render of ProductInfo will be called
2.a AddToCart Component will be mounted
    2.a.a. constructor and Other mounting lifecycle methods will be excuted;render of AddToCart will be excuted
    2.a.b mapping of virtual Dom to real DOM ; real Dom will be updated
    2.a.c. Other mounting lifecycle methods will be excuted
3. If call back exists, execute it


To unmount AddToCart:
state.showAddToCart -- false using setState()
1. State will be modified
2. render of ProductInfo will be called
2.a AddToCart Component will be unmounted(if it is mounted)
    2.a.a. componentWillUnmount() of AddToCart will be excuted
3. If call back exists, execute it

showAddToCart -- ProductsInfo
Can state.showAddToCart be accessible in AddToCart -- NO

Data flow from child to parent

In Component Sample:
<input type="button" value="add" onClick={this.addEventHandler} />
1. input tag -- written in Sample component
2. Onclick event -- inside the input opening tag
3. addEventHandler -- inside the Sample component outside the render
4. event gets triggered -- user click on the button

Sample -- ProductInfo -- parent
input -- AddToCart -- child


*/