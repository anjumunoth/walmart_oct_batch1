// ES6 feature
// ECMA script -- official name of java script
// ES6 -- 6th version of js -- 2015; ES2015

New features pf ES6

map method -- called only on array

var arr1=[10,20,30,40,50];
var sqArr=[];
for(i=0;i<arr1.length;i++)
{
    sqArr[i]=arr1[i]*arr1[i];
}

sqArr=arr1.map(function (item)
{
    return item*item;
})
console.log(sqArr);//[100,400,900,1600,2500]

1. Map through the various elements of arr1
Assign arr1[0] to item and execute the function.
return 100 ; 100 will be stored at sqArr[0]

2.Assign arr1[1] to item and execute the function.
return 400 ; 400 will be stored at sqArr[1]
....

Map function:
-- Always called on an array
-- Always return an array
-- Size of resultant array = size of target array
-- Execute the passed function on each and every element of array
arr1[10,20,30,40,50]
sqArrGreaterThan30=arr1.map(function (item)
{
    if(item >30)
        return item*item;
})
console.log(sqArrGreaterThan30);//[ud,ud,ud,1600,2500]
var i;
console.log(i);//undefined

function myFunc(p1,p2)
{
    return p1+p2;
}

var f1= (p1,p2) => {return p1+p2}
var f1= (p1,p2) => (p1+p2)

var f1 = p1 => (p1*p1)

var f1= () => {
    console.log("Have a great day")
}


var obj={
    empId:101,
    empName:"sara",
    display:function(){
        console.log("Inside display");
        console.log("Emp Id :"+ this.empId)
    },
    printDetails: ()=>{
        console.log("Inside print Details");
        console.log("Emp Id :"+ this.empId)
    }

}
obj.display();//Inside display;101
obj.printDetails();//Inside print Details;// ud 

Fat arrow fuction : scope of "this" operator : lexical scope

var i=0,j=2,k=3;
if( (i > j) && (++k<1))
{
    console.log("true part");
}
else
{
    console.log("false");
}
console.log(k);//3
