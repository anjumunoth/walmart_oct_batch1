import React from 'react'
import {useParams,useLocation} from "react-router-dom"

export default function Details() {
    var params=useParams();
    var location=useLocation();
    console.log("Location",location);
  return (
    <div>
        <h1>Details</h1>
        <h1>User Id : {params.userId}</h1>
        <h1>{JSON.stringify(location.state.selectedUser)}</h1>
    </div>
  )
}
