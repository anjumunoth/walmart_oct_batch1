import React from 'react'
import { Routes,Route } from 'react-router-dom'
import ProductsInfo from './ProductsInfo'
import ContactUs from './ContactUs'
import Users from './Users'
import Details from './Details'

export default function Home() {
  return (
    <div>
        <Routes>
            <Route path="users" element={<Users></Users>}></Route>
            <Route path="/products" element={<ProductsInfo></ProductsInfo>}></Route>
            <Route path="/contactus" element={<ContactUs></ContactUs>}></Route>
            <Route path="/details/:userId" element={<Details></Details>}></Route>
        </Routes>
    </div>
  )
}
