import './App.css';

import Header from "./Header"
import Footer from "./Footer"
import ProductsInfo from './ProductsInfo';
import Menu from './Menu';
import Home from './Home';

function App() {

  return (
    <div>
      <Header></Header>
     <Menu></Menu>
     <Home></Home>
      <Footer></Footer>
    </div>
  );
}
export default App;
/*
App -- functional component
-- return the virtual DOM

<h1 style="border:5px solid red"
*/