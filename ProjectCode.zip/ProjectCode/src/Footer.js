import React from "react";

class Footer extends React.Component
{
    render()
    {
        return (
            <h1>Footer Component</h1>
        )
    }
}

export default Footer;