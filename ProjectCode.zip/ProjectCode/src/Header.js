import React from "react";

// class component
class Header extends React.Component
{
    // render method -- mandatory -- return the virtual DOM
    render()
    {
        return (
            <div className="container-fluid">
                <div className="bg-warning row align-items-center">
                    <img src="./images/walmartLogo.jpg" alt="walmart Logo" className="col-4"/>
                    <h1 className="text-primary col-8 text-center">Walmart shopping</h1>
                </div>     
            </div>
           
        );
    }
}

export default Header;
/*
primary -- blue
success -- green
warning -- yellow
secondary -- grey
danger -- red

grid layout -- rows and columns
Each row -- 12 columns
h1 - 8 columns
img - 4 columns

container
row
h1- 8 columns
img - 4 columns
*/